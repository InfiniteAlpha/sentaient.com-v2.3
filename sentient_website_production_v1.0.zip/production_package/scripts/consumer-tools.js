// consumer-tools.js - Consumer-facing interactive tools for Sentient website
// Tools with viral potential and lead generation capabilities

// =============================================================================
// UTILITY FUNCTIONS
// =============================================================================

const ConsumerUtils = {
    validateEmail: (email) => {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    },

    serializeForm: (formElement) => {
        const formData = new FormData(formElement);
        const data = {};
        for (let [key, value] of formData.entries()) {
            data[key] = value;
        }
        return data;
    },

    saveProgress: (toolName, data) => {
        try {
            localStorage.setItem(`sentient_${toolName}`, JSON.stringify({
                data: data,
                timestamp: new Date().toISOString()
            }));
        } catch (e) {
            console.warn('LocalStorage not available:', e);
        }
    },

    loadProgress: (toolName) => {
        try {
            const stored = localStorage.getItem(`sentient_${toolName}`);
            return stored ? JSON.parse(stored) : null;
        } catch (e) {
            console.warn('LocalStorage not available:', e);
            return null;
        }
    },

    logEvent: (eventName, eventData) => {
        // Analytics tracking
    },

    fadeIn: (element, duration = 300) => {
        element.style.opacity = '0';
        element.style.display = 'block';
        let start = null;
        
        const animate = (timestamp) => {
            if (!start) start = timestamp;
            const progress = (timestamp - start) / duration;
            element.style.opacity = Math.min(progress, 1);
            if (progress < 1) requestAnimationFrame(animate);
        };
        requestAnimationFrame(animate);
    },

    fadeOut: (element, duration = 300) => {
        let start = null;
        const initialOpacity = parseFloat(getComputedStyle(element).opacity) || 1;
        
        const animate = (timestamp) => {
            if (!start) start = timestamp;
            const progress = (timestamp - start) / duration;
            element.style.opacity = initialOpacity * (1 - Math.min(progress, 1));
            if (progress < 1) {
                requestAnimationFrame(animate);
            } else {
                element.style.display = 'none';
            }
        };
        requestAnimationFrame(animate);
    }
};

// =============================================================================
// AI CAPABILITY DEMO TOOL
// =============================================================================

const AIDemo = {
    scenarios: [
        {
            id: 'schedule',
            title: 'Schedule Meeting',
            prompt: 'Schedule a team meeting for next Tuesday at 2pm',
            response: 'I\'ve analyzed your calendar and team availability. I can schedule your meeting for Tuesday, November 19th at 2:00 PM EST. I\'ve identified 5 team members who are available and sent calendar invites. Would you like me to prepare an agenda based on your recent project updates?',
            tags: ['productivity', 'automation']
        },
        {
            id: 'analyze',
            title: 'Analyze Data',
            prompt: 'Analyze our Q4 sales performance',
            response: 'Q4 sales analysis complete: Revenue increased 23% vs Q3, driven primarily by enterprise segment (+45%). Top performing regions: Northeast (32% growth) and West Coast (28% growth). Key insight: Customer acquisition cost decreased 15% while retention improved to 94%. I\'ve identified 3 optimization opportunities worth an estimated $150K in additional revenue.',
            tags: ['analytics', 'business intelligence']
        },
        {
            id: 'customer',
            title: 'Customer Service',
            prompt: 'Help customer with order #12345',
            response: 'Order #12345 status: Shipped via FedEx, tracking #789456123, estimated delivery tomorrow by 5pm. Customer Sarah Johnson has premium support tier. Previous interactions show high satisfaction (4.8/5 avg). I\'ve prepared a proactive update email and identified an upsell opportunity for complementary product based on her purchase history.',
            tags: ['customer service', 'support automation']
        },
        {
            id: 'research',
            title: 'Market Research',
            prompt: 'Research competitors in fintech AI space',
            response: 'Analyzed 47 fintech AI competitors. Key findings: Market growing at 34% CAGR, dominated by 5 major players controlling 62% share. Gap identified: SMB segment (10-100 employees) underserved with only 3 focused solutions. Average pricing: $500-2000/month. Your differentiation opportunities: personalized onboarding, vertical-specific features, hybrid human-AI support model.',
            tags: ['research', 'competitive intelligence']
        }
    ],

    init: () => {
        const container = document.getElementById('ai-demo-tool');
        if (!container) return;

        AIDemo.render(container);
        ConsumerUtils.logEvent('ai_demo_viewed', { timestamp: new Date().toISOString() });
    },

    render: (container) => {
        container.innerHTML = `
            <div class="ai-demo-container">
                <h3 class="tool-title">Try Our AI Agent</h3>
                <p class="tool-subtitle">Select a scenario or enter your own prompt</p>
                
                <div class="demo-scenarios">
                    ${AIDemo.scenarios.map(s => `
                        <button class="scenario-card" data-scenario="${s.id}">
                            <strong>${s.title}</strong>
                            <span class="scenario-tags">${s.tags.map(t => `<span class="tag">${t}</span>`).join('')}</span>
                        </button>
                    `).join('')}
                </div>

                <div class="demo-custom-input">
                    <textarea id="demo-prompt" placeholder="Or type your own request..." rows="3"></textarea>
                    <button id="demo-submit" class="btn-primary">Try It Now</button>
                </div>

                <div id="demo-response" class="demo-response" style="display:none;">
                    <div class="response-header">
                        <span class="ai-badge">AI Agent Response</span>
                        <span class="response-time">⚡ Responded in 0.8s</span>
                    </div>
                    <div class="response-content"></div>
                    <div class="response-actions">
                        <button class="btn-secondary share-result">Share This Result</button>
                        <button class="btn-primary start-trial">Start Free Trial</button>
                    </div>
                </div>
            </div>
        `;

        AIDemo.attachListeners(container);
    },

    attachListeners: (container) => {
        container.querySelectorAll('.scenario-card').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const scenarioId = e.currentTarget.dataset.scenario;
                AIDemo.runScenario(scenarioId);
            });
        });

        const submitBtn = container.querySelector('#demo-submit');
        const promptInput = container.querySelector('#demo-prompt');
        
        if (submitBtn && promptInput) {
            submitBtn.addEventListener('click', () => {
                const customPrompt = promptInput.value.trim();
                if (customPrompt) {
                    AIDemo.runCustom(customPrompt);
                }
            });

            promptInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    submitBtn.click();
                }
            });
        }
    },

    runScenario: (scenarioId) => {
        const scenario = AIDemo.scenarios.find(s => s.id === scenarioId);
        if (!scenario) return;

        ConsumerUtils.logEvent('ai_demo_scenario_selected', { scenario: scenarioId });
        AIDemo.showResponse(scenario.response, scenario.title);
    },

    runCustom: (prompt) => {
        ConsumerUtils.logEvent('ai_demo_custom_prompt', { prompt_length: prompt.length });
        
        const response = `I understand you'd like help with: "${prompt}". Our AI agents can handle complex requests like this by analyzing context, accessing relevant data sources, and providing actionable insights. Start your free trial to see how our AI can transform your workflow with real capabilities tailored to your needs.`;
        
        AIDemo.showResponse(response, 'Custom Request');
    },

    showResponse: (responseText, title) => {
        const responseDiv = document.getElementById('demo-response');
        if (!responseDiv) return;
        
        const contentDiv = responseDiv.querySelector('.response-content');
        contentDiv.innerHTML = `<p>${responseText}</p>`;
        
        ConsumerUtils.fadeIn(responseDiv);
        responseDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

        const shareBtn = responseDiv.querySelector('.share-result');
        const trialBtn = responseDiv.querySelector('.start-trial');
        
        if (shareBtn) {
            shareBtn.onclick = () => AIDemo.shareResult(title, responseText);
        }
        
        if (trialBtn) {
            trialBtn.onclick = () => {
                ConsumerUtils.logEvent('demo_to_trial_clicked', { source: 'ai_demo' });
                const trialSection = document.getElementById('trial-signup-tool');
                if (trialSection) {
                    trialSection.scrollIntoView({ behavior: 'smooth' });
                }
            };
        }
    },

    shareResult: (title, response) => {
        const shareData = {
            title: `Amazing AI Demo: ${title}`,
            text: `I just tried Sentient's AI agent and got impressive results! ${response.substring(0, 100)}...`,
            url: window.location.href
        };

        if (navigator.share) {
            navigator.share(shareData).then(() => {
                ConsumerUtils.logEvent('demo_shared', { method: 'native', title: title });
            }).catch(err => {});
        } else {
            AIDemo.showShareButtons(shareData);
        }
    },

    showShareButtons: (shareData) => {
        const text = encodeURIComponent(shareData.text);
        const url = encodeURIComponent(shareData.url);
        
        const existingModal = document.querySelector('.share-modal');
        if (existingModal) existingModal.remove();
        
        const shareHtml = `
            <div class="share-modal">
                <div class="share-modal-content">
                    <button class="modal-close">×</button>
                    <h4>Share This Result</h4>
                    <div class="share-buttons">
                        <a href="https://twitter.com/intent/tweet?text=${text}&url=${url}" target="_blank" class="share-btn twitter">Twitter</a>
                        <a href="https://www.linkedin.com/sharing/share-offsite/?url=${url}" target="_blank" class="share-btn linkedin">LinkedIn</a>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=${url}" target="_blank" class="share-btn facebook">Facebook</a>
                        <button class="share-btn copy" data-url="${shareData.url}">Copy Link</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', shareHtml);
        
        const modal = document.querySelector('.share-modal');
        const closeBtn = modal.querySelector('.modal-close');
        const copyBtn = modal.querySelector('.copy');
        
        closeBtn.addEventListener('click', () => modal.remove());
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });
        
        copyBtn.addEventListener('click', () => {
            navigator.clipboard.writeText(copyBtn.dataset.url).then(() => {
                copyBtn.textContent = '✓ Copied!';
                setTimeout(() => copyBtn.textContent = 'Copy Link', 2000);
            });
        });
        
        ConsumerUtils.logEvent('share_modal_shown', { source: 'ai_demo' });
    }
};

// =============================================================================
// INTERACTIVE ASSESSMENT QUIZ TOOL
// =============================================================================

const AssessmentQuiz = {
    questions: [
        {
            id: 'business_type',
            text: 'What best describes your business?',
            options: [
                { value: 'finance', label: 'Finance/Banking', score: { agents: 10, automation: 8 } },
                { value: 'tech', label: 'Technology/SaaS', score: { agents: 9, automation: 9 } },
                { value: 'hospitality', label: 'Hospitality/Travel', score: { agents: 8, automation: 7 } },
                { value: 'ecommerce', label: 'E-commerce/Retail', score: { agents: 7, automation: 10 } },
                { value: 'other', label: 'Other Industry', score: { agents: 6, automation: 6 } }
            ]
        },
        {
            id: 'team_size',
            text: 'How large is your team?',
            options: [
                { value: 'solo', label: '1-5 employees', score: { agents: 5, automation: 8 } },
                { value: 'small', label: '6-25 employees', score: { agents: 8, automation: 9 } },
                { value: 'medium', label: '26-100 employees', score: { agents: 10, automation: 10 } },
                { value: 'large', label: '100+ employees', score: { agents: 9, automation: 8 } }
            ]
        },
        {
            id: 'challenges',
            text: 'What\'s your biggest operational challenge?',
            options: [
                { value: 'repetitive', label: 'Too many repetitive tasks', score: { agents: 10, automation: 10 } },
                { value: 'data', label: 'Managing/analyzing data', score: { agents: 9, automation: 7 } },
                { value: 'customer', label: 'Customer service volume', score: { agents: 10, automation: 8 } },
                { value: 'scaling', label: 'Scaling operations', score: { agents: 8, automation: 9 } }
            ]
        },
        {
            id: 'tech_adoption',
            text: 'How would you rate your tech adoption?',
            options: [
                { value: 'early', label: 'Early adopter - love new tech', score: { agents: 10, automation: 10 } },
                { value: 'moderate', label: 'Moderate - wait for proven solutions', score: { agents: 8, automation: 8 } },
                { value: 'conservative', label: 'Conservative - stick with what works', score: { agents: 6, automation: 6 } }
            ]
        },
        {
            id: 'goals',
            text: 'What\'s your primary goal for AI adoption?',
            options: [
                { value: 'cost', label: 'Reduce operational costs', score: { agents: 7, automation: 10 } },
                { value: 'speed', label: 'Increase speed/efficiency', score: { agents: 9, automation: 9 } },
                { value: 'quality', label: 'Improve output quality', score: { agents: 10, automation: 7 } },
                { value: 'scale', label: 'Scale without hiring', score: { agents: 10, automation: 10 } }
            ]
        }
    ],

    currentQuestion: 0,
    answers: {},
    scores: { agents: 0, automation: 0 },

    init: () => {
        const container = document.getElementById('assessment-quiz-tool');
        if (!container) return;

        const saved = ConsumerUtils.loadProgress('assessment_quiz');
        if (saved && saved.data) {
            AssessmentQuiz.answers = saved.data.answers || {};
            AssessmentQuiz.currentQuestion = saved.data.currentQuestion || 0;
            AssessmentQuiz.scores = saved.data.scores || { agents: 0, automation: 0 };
        }

        AssessmentQuiz.render(container);
        ConsumerUtils.logEvent('assessment_quiz_started', { timestamp: new Date().toISOString() });
    },

    render: (container) => {
        if (AssessmentQuiz.currentQuestion >= AssessmentQuiz.questions.length) {
            AssessmentQuiz.showResults(container);
            return;
        }

        const question = AssessmentQuiz.questions[AssessmentQuiz.currentQuestion];
        const progress = ((AssessmentQuiz.currentQuestion + 1) / AssessmentQuiz.questions.length) * 100;

        container.innerHTML = `
            <div class="quiz-container">
                <div class="quiz-progress">
                    <div class="quiz-progress-bar" style="width: ${progress}%"></div>
                    <span class="quiz-progress-text">Question ${AssessmentQuiz.currentQuestion + 1} of ${AssessmentQuiz.questions.length}</span>
                </div>

                <div class="quiz-question">
                    <h3>${question.text}</h3>
                    <div class="quiz-options">
                        ${question.options.map(opt => `
                            <button class="quiz-option" data-value="${opt.value}">
                                ${opt.label}
                            </button>
                        `).join('')}
                    </div>
                </div>

                ${AssessmentQuiz.currentQuestion > 0 ? '<button class="quiz-back btn-secondary">← Back</button>' : ''}
            </div>
        `;

        AssessmentQuiz.attachQuizListeners(container);
    },

    attachQuizListeners: (container) => {
        container.querySelectorAll('.quiz-option').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const value = e.currentTarget.dataset.value;
                const question = AssessmentQuiz.questions[AssessmentQuiz.currentQuestion];
                
                AssessmentQuiz.answers[question.id] = value;
                
                const selected = question.options.find(o => o.value === value);
                if (selected && selected.score) {
                    AssessmentQuiz.scores.agents += selected.score.agents || 0;
                    AssessmentQuiz.scores.automation += selected.score.automation || 0;
                }

                ConsumerUtils.saveProgress('assessment_quiz', {
                    answers: AssessmentQuiz.answers,
                    currentQuestion: AssessmentQuiz.currentQuestion,
                    scores: AssessmentQuiz.scores
                });

                ConsumerUtils.logEvent('quiz_question_answered', {
                    question: question.id,
                    answer: value,
                    questionNumber: AssessmentQuiz.currentQuestion + 1
                });

                AssessmentQuiz.currentQuestion++;
                AssessmentQuiz.render(container);
            });
        });

        const backBtn = container.querySelector('.quiz-back');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                AssessmentQuiz.currentQuestion = Math.max(0, AssessmentQuiz.currentQuestion - 1);
                AssessmentQuiz.render(container);
            });
        }
    },

    showResults: (container) => {
        const totalScore = AssessmentQuiz.scores.agents + AssessmentQuiz.scores.automation;
        const avgScore = Math.round(totalScore / 2);
        
        let recommendation = '';
        let readinessLevel = '';
        let services = [];

        if (avgScore >= 85) {
            readinessLevel = 'Advanced';
            recommendation = 'You\'re an ideal candidate for our comprehensive AI Agent platform! Your business is ready for advanced automation and intelligent agents that can transform your operations.';
            services = ['Custom AI Agents', 'Enterprise Automation', 'Strategic AI Consulting'];
        } else if (avgScore >= 70) {
            readinessLevel = 'Intermediate';
            recommendation = 'Your business shows strong potential for AI adoption! We recommend starting with targeted automation in high-impact areas, then expanding to full AI agent deployment.';
            services = ['Task Automation', 'AI-Powered Analytics', 'Digital Marketing AI'];
        } else {
            readinessLevel = 'Beginner';
            recommendation = 'Great timing to start your AI journey! We recommend beginning with simple automation tasks to build confidence, then gradually introducing AI agents as your team adapts.';
            services = ['Process Automation', 'AI Consulting', 'Training & Onboarding'];
        }

        container.innerHTML = `
            <div class="quiz-results">
                <div class="results-header">
                    <h2>Your AI Readiness Assessment</h2>
                    <div class="readiness-badge ${readinessLevel.toLowerCase()}">${readinessLevel}</div>
                </div>

                <div class="results-score">
                    <div class="score-circle">
                        <svg width="200" height="200">
                            <circle cx="100" cy="100" r="80" fill="none" stroke="#e0e0e0" stroke-width="20"/>
                            <circle cx="100" cy="100" r="80" fill="none" stroke="#60a9ff" stroke-width="20"
                                stroke-dasharray="${avgScore * 5.02} 502" transform="rotate(-90 100 100)"/>
                        </svg>
                        <div class="score-text">
                            <span class="score-number">${avgScore}</span>
                            <span class="score-label">/100</span>
                        </div>
                    </div>
                </div>

                <div class="results-recommendation">
                    <h3>Recommendation</h3>
                    <p>${recommendation}</p>
                </div>

                <div class="results-services">
                    <h3>Recommended Services</h3>
                    <ul>
                        ${services.map(s => `<li>✓ ${s}</li>`).join('')}
                    </ul>
                </div>

                <div class="results-actions">
                    <button class="btn-primary get-detailed-report">Get Detailed Report via Email</button>
                    <button class="btn-secondary share-results">Share My Results</button>
                    <button class="btn-secondary restart-quiz">Retake Assessment</button>
                </div>
            </div>
        `;

        const emailBtn = container.querySelector('.get-detailed-report');
        const shareBtn = container.querySelector('.share-results');
        const restartBtn = container.querySelector('.restart-quiz');
        
        if (emailBtn) {
            emailBtn.addEventListener('click', () => {
                AssessmentQuiz.showEmailCapture(container, avgScore, readinessLevel, services);
            });
        }

        if (shareBtn) {
            shareBtn.addEventListener('click', () => {
                AssessmentQuiz.shareResults(avgScore, readinessLevel);
            });
        }

        if (restartBtn) {
            restartBtn.addEventListener('click', () => {
                AssessmentQuiz.restart(container);
            });
        }

        ConsumerUtils.logEvent('quiz_completed', {
            score: avgScore,
            readiness: readinessLevel,
            answers: AssessmentQuiz.answers
        });
    },

    showEmailCapture: (container, score, level, services) => {
        const existingModal = document.querySelector('.email-capture-modal');
        if (existingModal) existingModal.remove();
        
        const modal = document.createElement('div');
        modal.className = 'email-capture-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <button class="modal-close">×</button>
                <h3>Get Your Detailed AI Readiness Report</h3>
                <p>Receive a comprehensive PDF report with:</p>
                <ul>
                    <li>Detailed analysis of your AI readiness</li>
                    <li>Custom implementation roadmap</li>
                    <li>ROI projections for your business</li>
                    <li>Competitive benchmarking insights</li>
                </ul>
                <form id="email-capture-form">
                    <input type="text" name="name" placeholder="Your Name" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                    <input type="hidden" name="score" value="${score}">
                    <input type="hidden" name="level" value="${level}">
                    <div class="privacy-notice">
                        <input type="checkbox" id="privacy-agree" required>
                        <label for="privacy-agree">I agree to receive the report and occasional updates. <a href="#">Privacy Policy</a></label>
                    </div>
                    <button type="submit" class="btn-primary">Send My Report</button>
                </form>
            </div>
        `;

        document.body.appendChild(modal);
        ConsumerUtils.fadeIn(modal);

        modal.querySelector('.modal-close').addEventListener('click', () => {
            ConsumerUtils.fadeOut(modal, 200);
            setTimeout(() => modal.remove(), 200);
        });
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                ConsumerUtils.fadeOut(modal, 200);
                setTimeout(() => modal.remove(), 200);
            }
        });

        modal.querySelector('#email-capture-form').addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = ConsumerUtils.serializeForm(e.target);
            
            if (!ConsumerUtils.validateEmail(formData.email)) {
                alert('Please enter a valid email address');
                return;
            }

            ConsumerUtils.logEvent('email_captured', {
                source: 'assessment_quiz',
                score: score,
                level: level
            });

            modal.querySelector('.modal-content').innerHTML = `
                <h3>✓ Success!</h3>
                <p>Your detailed AI readiness report has been sent to <strong>${formData.email}</strong></p>
                <p>Check your inbox in the next few minutes. Don't forget to check your spam folder!</p>
                <button class="btn-primary close-success">Close</button>
            `;
            
            modal.querySelector('.close-success').addEventListener('click', () => modal.remove());
        });
    },

    shareResults: (score, level) => {
        const shareText = `I scored ${score}/100 (${level}) on Sentient's AI Readiness Assessment! Discover your AI potential:`;
        const shareUrl = window.location.href;

        if (navigator.share) {
            navigator.share({
                title: 'My AI Readiness Score',
                text: shareText,
                url: shareUrl
            }).catch(err => {});
        } else {
            const encoded = encodeURIComponent(shareText);
            const urlEncoded = encodeURIComponent(shareUrl);
            
            const existingModal = document.querySelector('.share-modal');
            if (existingModal) existingModal.remove();
            
            const shareHtml = `
                <div class="share-modal">
                    <div class="share-modal-content">
                        <button class="modal-close">×</button>
                        <h4>Share Your Score</h4>
                        <div class="share-badge">${score}/100 - ${level}</div>
                        <div class="share-buttons">
                            <a href="https://twitter.com/intent/tweet?text=${encoded}&url=${urlEncoded}" target="_blank" class="share-btn">Twitter</a>
                            <a href="https://www.linkedin.com/sharing/share-offsite/?url=${urlEncoded}" target="_blank" class="share-btn">LinkedIn</a>
                            <button class="share-btn copy" data-url="${shareUrl}">Copy Link</button>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.insertAdjacentHTML('beforeend', shareHtml);
            
            const modal = document.querySelector('.share-modal');
            const closeBtn = modal.querySelector('.modal-close');
            const copyBtn = modal.querySelector('.copy');
            
            closeBtn.addEventListener('click', () => modal.remove());
            modal.addEventListener('click', (e) => {
                if (e.target === modal) modal.remove();
            });
            
            copyBtn.addEventListener('click', () => {
                navigator.clipboard.writeText(copyBtn.dataset.url).then(() => {
                    copyBtn.textContent = '✓ Copied!';
                    setTimeout(() => copyBtn.textContent = 'Copy Link', 2000);
                });
            });
        }

        ConsumerUtils.logEvent('quiz_results_shared', { score, level });
    },

    restart: (container) => {
        AssessmentQuiz.currentQuestion = 0;
        AssessmentQuiz.answers = {};
        AssessmentQuiz.scores = { agents: 0, automation: 0 };
        localStorage.removeItem('sentient_assessment_quiz');
        AssessmentQuiz.render(container);
        ConsumerUtils.logEvent('quiz_restarted', {});
    }
};

// =============================================================================
// SAVINGS CALCULATOR (Lead Magnet)
// =============================================================================

const SavingsCalculator = {
    init: () => {
        const container = document.getElementById('savings-calculator-tool');
        if (!container) return;

        SavingsCalculator.render(container);
        ConsumerUtils.logEvent('savings_calculator_viewed', {});
    },

    render: (container) => {
        container.innerHTML = `
            <div class="calculator-container">
                <h3 class="tool-title">Calculate Your Automation Savings</h3>
                <p class="tool-subtitle">Discover how much time and money AI automation could save your business</p>

                <form id="savings-form" class="calculator-form">
                    <div class="form-group">
                        <label for="employees">Number of Employees</label>
                        <input type="number" id="employees" name="employees" min="1" max="10000" value="10" required>
                    </div>

                    <div class="form-group">
                        <label for="hours-manual">Hours/Week on Repetitive Tasks (per employee)</label>
                        <input type="number" id="hours-manual" name="hours_manual" min="1" max="40" value="5" step="0.5" required>
                        <span class="help-text">e.g., data entry, report generation, email management</span>
                    </div>

                    <div class="form-group">
                        <label for="hourly-cost">Average Hourly Cost ($/hour)</label>
                        <input type="number" id="hourly-cost" name="hourly_cost" min="10" max="500" value="50" required>
                        <span class="help-text">Include salary, benefits, overhead</span>
                    </div>

                    <div class="form-group">
                        <label for="task-frequency">Task Frequency</label>
                        <select id="task-frequency" name="task_frequency" required>
                            <option value="1">Daily</option>
                            <option value="0.7">Several times per week</option>
                            <option value="0.25">Weekly</option>
                            <option value="0.1">Monthly</option>
                        </select>
                    </div>

                    <button type="submit" class="btn-primary calculator-submit">Calculate My Savings</button>
                </form>

                <div id="calculator-results" class="calculator-results" style="display:none;"></div>
            </div>
        `;

        SavingsCalculator.attachListeners(container);
    },

    attachListeners: (container) => {
        const form = container.querySelector('#savings-form');
        
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = ConsumerUtils.serializeForm(form);
            SavingsCalculator.calculate(formData, container);
        });

        form.querySelectorAll('input').forEach(input => {
            input.addEventListener('input', () => {
                const resultsDiv = container.querySelector('#calculator-results');
                if (resultsDiv && resultsDiv.style.display !== 'none') {
                    const submitBtn = form.querySelector('.calculator-submit');
                    if (submitBtn) submitBtn.textContent = 'Recalculate';
                }
            });
        });
    },

    calculate: (data, container) => {
        const employees = parseInt(data.employees);
        const hoursManual = parseFloat(data.hours_manual);
        const hourlyCost = parseFloat(data.hourly_cost);
        const frequency = parseFloat(data.task_frequency);

        const automationEfficiency = 0.75;
        
        const weeklyHoursSaved = employees * hoursManual * automationEfficiency * frequency;
        const annualHoursSaved = weeklyHoursSaved * 52;
        const annualCostSavings = annualHoursSaved * hourlyCost;
        const monthlySavings = annualCostSavings / 12;
        
        const roiMultiplier = 8;
        const estimatedROI = annualCostSavings * roiMultiplier;

        ConsumerUtils.logEvent('savings_calculated', {
            employees,
            weekly_hours_saved: weeklyHoursSaved,
            annual_savings: annualCostSavings
        });

        SavingsCalculator.showPreviewResults(container, {
            weeklyHours: Math.round(weeklyHoursSaved),
            annualHours: Math.round(annualHoursSaved),
            annualSavings: Math.round(annualCostSavings),
            monthlySavings: Math.round(monthlySavings),
            roi: Math.round(estimatedROI)
        });
    },

    showPreviewResults: (container, results) => {
        const resultsDiv = container.querySelector('#calculator-results');
        
        resultsDiv.innerHTML = `
            <div class="results-preview">
                <h3>Your Potential Savings</h3>
                
                <div class="savings-highlight">
                    <div class="savings-stat">
                        <span class="stat-value">$${results.annualSavings.toLocaleString()}</span>
                        <span class="stat-label">Annual Cost Savings</span>
                    </div>
                    <div class="savings-stat">
                        <span class="stat-value">${results.weeklyHours}</span>
                        <span class="stat-label">Hours Saved Per Week</span>
                    </div>
                </div>

                <div class="preview-message">
                    <p><strong>🔒 Get Your Detailed Report</strong></p>
                    <p>Unlock the complete analysis including:</p>
                    <ul>
                        <li>Month-by-month savings projection</li>
                        <li>ROI timeline and break-even analysis</li>
                        <li>Recommended automation priorities</li>
                        <li>Custom implementation roadmap</li>
                        <li>Competitive benchmarking data</li>
                    </ul>
                </div>

                <form id="email-unlock-form" class="email-unlock-form">
                    <input type="email" name="email" placeholder="Enter your email for detailed report" required>
                    <input type="hidden" name="annual_savings" value="${results.annualSavings}">
                    <input type="hidden" name="weekly_hours" value="${results.weeklyHours}">
                    <div class="privacy-checkbox">
                        <input type="checkbox" id="privacy-calc" required>
                        <label for="privacy-calc">I agree to receive the detailed report. <a href="#">Privacy Policy</a></label>
                    </div>
                    <button type="submit" class="btn-primary">Get Detailed Report</button>
                </form>

                <button class="btn-secondary share-savings">Share These Savings</button>
            </div>
        `;

        ConsumerUtils.fadeIn(resultsDiv);
        resultsDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

        const emailForm = resultsDiv.querySelector('#email-unlock-form');
        emailForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = emailForm.querySelector('input[name="email"]').value;
            
            if (!ConsumerUtils.validateEmail(email)) {
                alert('Please enter a valid email address');
                return;
            }

            SavingsCalculator.showDetailedResults(container, results, email);
        });

        const shareBtn = resultsDiv.querySelector('.share-savings');
        shareBtn.addEventListener('click', () => {
            SavingsCalculator.shareResults(results);
        });
    },

    showDetailedResults: (container, results, email) => {
        ConsumerUtils.logEvent('email_captured', {
            source: 'savings_calculator',
            email: email,
            annual_savings: results.annualSavings
        });

        const resultsDiv = container.querySelector('#calculator-results');
        
        resultsDiv.innerHTML = `
            <div class="detailed-results">
                <div class="success-message">
                    <h3>✓ Report Sent!</h3>
                    <p>Your detailed savings analysis has been sent to <strong>${email}</strong></p>
                </div>

                <div class="detailed-breakdown">
                    <h4>Your Complete Savings Analysis</h4>
                    
                    <div class="breakdown-grid">
                        <div class="breakdown-item">
                            <span class="breakdown-label">Weekly Time Savings</span>
                            <span class="breakdown-value">${results.weeklyHours} hours</span>
                        </div>
                        <div class="breakdown-item">
                            <span class="breakdown-label">Annual Time Savings</span>
                            <span class="breakdown-value">${results.annualHours.toLocaleString()} hours</span>
                        </div>
                        <div class="breakdown-item">
                            <span class="breakdown-label">Monthly Cost Savings</span>
                            <span class="breakdown-value">$${results.monthlySavings.toLocaleString()}</span>
                        </div>
                        <div class="breakdown-item">
                            <span class="breakdown-label">Annual Cost Savings</span>
                            <span class="breakdown-value">$${results.annualSavings.toLocaleString()}</span>
                        </div>
                        <div class="breakdown-item highlight">
                            <span class="breakdown-label">Estimated 3-Year ROI</span>
                            <span class="breakdown-value">$${results.roi.toLocaleString()}</span>
                        </div>
                    </div>

                    <div class="implementation-timeline">
                        <h4>Recommended Implementation Timeline</h4>
                        <div class="timeline">
                            <div class="timeline-item">
                                <span class="timeline-phase">Month 1-2</span>
                                <span class="timeline-desc">Process audit & automation planning</span>
                            </div>
                            <div class="timeline-item">
                                <span class="timeline-phase">Month 3-4</span>
                                <span class="timeline-desc">Deploy first automation workflows</span>
                            </div>
                            <div class="timeline-item">
                                <span class="timeline-phase">Month 5-6</span>
                                <span class="timeline-desc">Scale and optimize operations</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="cta-section">
                    <h4>Ready to Start Saving?</h4>
                    <button class="btn-primary schedule-consultation">Schedule Free Consultation</button>
                    <button class="btn-secondary share-detailed">Share This Report</button>
                </div>
            </div>
        `;

        const consultBtn = resultsDiv.querySelector('.schedule-consultation');
        const shareBtn = resultsDiv.querySelector('.share-detailed');
        
        if (consultBtn) {
            consultBtn.addEventListener('click', () => {
                ConsumerUtils.logEvent('consultation_clicked', { source: 'savings_calculator' });
                window.location.href = '/pages/alternate/contact_alt.html';
            });
        }

        if (shareBtn) {
            shareBtn.addEventListener('click', () => {
                SavingsCalculator.shareResults(results);
            });
        }
    },

    shareResults: (results) => {
        const shareText = `I could save $${results.annualSavings.toLocaleString()}/year with AI automation! Calculate your savings:`;
        const shareUrl = window.location.href;

        if (navigator.share) {
            navigator.share({
                title: 'My Automation Savings',
                text: shareText,
                url: shareUrl
            }).catch(err => {});
        } else {
            const encoded = encodeURIComponent(shareText);
            const urlEncoded = encodeURIComponent(shareUrl);
            
            window.open(`https://twitter.com/intent/tweet?text=${encoded}&url=${urlEncoded}`, '_blank');
        }

        ConsumerUtils.logEvent('calculator_results_shared', { annual_savings: results.annualSavings });
    }
};

// =============================================================================
// TRIAL SIGNUP INTERFACE
// =============================================================================

const TrialSignup = {
    currentStep: 0,
    formData: {},

    steps: [
        {
            id: 'info',
            title: 'Get Started',
            fields: [
                { name: 'name', type: 'text', label: 'Full Name', placeholder: 'John Smith', required: true },
                { name: 'email', type: 'email', label: 'Work Email', placeholder: 'john@company.com', required: true },
                { name: 'company', type: 'text', label: 'Company Name', placeholder: 'Acme Corp', required: false }
            ]
        },
        {
            id: 'usecase',
            title: 'Choose Your Focus',
            options: [
                { value: 'automation', label: 'Task Automation', icon: '⚡', desc: 'Automate repetitive workflows' },
                { value: 'analytics', label: 'Data Analytics', icon: '📊', desc: 'AI-powered insights' },
                { value: 'customer', label: 'Customer Service', icon: '💬', desc: 'Intelligent support agents' },
                { value: 'marketing', label: 'Marketing', icon: '📱', desc: 'AI-driven campaigns' }
            ]
        },
        {
            id: 'customize',
            title: 'Customize Your Experience',
            fields: [
                { name: 'industry', type: 'select', label: 'Industry', options: ['Finance', 'Technology', 'Healthcare', 'Retail', 'Other'], required: true },
                { name: 'team_size', type: 'select', label: 'Team Size', options: ['1-10', '11-50', '51-200', '200+'], required: true }
            ]
        }
    ],

    init: () => {
        const container = document.getElementById('trial-signup-tool');
        if (!container) return;

        const saved = ConsumerUtils.loadProgress('trial_signup');
        if (saved && saved.data) {
            TrialSignup.formData = saved.data.formData || {};
            TrialSignup.currentStep = saved.data.currentStep || 0;
        }

        TrialSignup.render(container);
        ConsumerUtils.logEvent('trial_signup_started', {});
    },

    render: (container) => {
        if (TrialSignup.currentStep >= TrialSignup.steps.length) {
            TrialSignup.showSuccess(container);
            return;
        }

        const step = TrialSignup.steps[TrialSignup.currentStep];
        const progress = ((TrialSignup.currentStep + 1) / TrialSignup.steps.length) * 100;

        let stepContent = '';
        
        if (step.fields) {
            stepContent = `
                <form id="trial-step-form" class="trial-form">
                    ${step.fields.map(field => {
                        if (field.type === 'select') {
                            return `
                                <div class="form-group">
                                    <label for="${field.name}">${field.label}</label>
                                    <select id="${field.name}" name="${field.name}" ${field.required ? 'required' : ''}>
                                        <option value="">Select...</option>
                                        ${field.options.map(opt => `<option value="${opt}">${opt}</option>`).join('')}
                                    </select>
                                </div>
                            `;
                        } else {
                            return `
                                <div class="form-group">
                                    <label for="${field.name}">${field.label}</label>
                                    <input type="${field.type}" id="${field.name}" name="${field.name}" 
                                        placeholder="${field.placeholder || ''}" 
                                        value="${TrialSignup.formData[field.name] || ''}"
                                        ${field.required ? 'required' : ''}>
                                </div>
                            `;
                        }
                    }).join('')}
                    <button type="submit" class="btn-primary">Continue →</button>
                </form>
            `;
        } else if (step.options) {
            stepContent = `
                <div class="trial-options">
                    ${step.options.map(opt => `
                        <button class="trial-option-card" data-value="${opt.value}">
                            <span class="option-icon">${opt.icon}</span>
                            <strong>${opt.label}</strong>
                            <span class="option-desc">${opt.desc}</span>
                        </button>
                    `).join('')}
                </div>
            `;
        }

        container.innerHTML = `
            <div class="trial-signup-container">
                <div class="trial-progress">
                    <div class="trial-progress-bar" style="width: ${progress}%"></div>
                    <span class="trial-progress-text">Step ${TrialSignup.currentStep + 1} of ${TrialSignup.steps.length}</span>
                </div>

                <div class="trial-step">
                    <h3 class="trial-step-title">${step.title}</h3>
                    ${stepContent}
                </div>

                ${TrialSignup.currentStep > 0 ? '<button class="trial-back btn-secondary">← Back</button>' : ''}
            </div>
        `;

        TrialSignup.attachTrialListeners(container);
    },

    attachTrialListeners: (container) => {
        const form = container.querySelector('#trial-step-form');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                const stepData = ConsumerUtils.serializeForm(form);
                
                let isValid = true;
                const step = TrialSignup.steps[TrialSignup.currentStep];
                
                step.fields.forEach(field => {
                    if (field.required && !stepData[field.name]) {
                        isValid = false;
                    }
                    if (field.type === 'email' && stepData[field.name] && !ConsumerUtils.validateEmail(stepData[field.name])) {
                        isValid = false;
                        alert('Please enter a valid email address');
                    }
                });

                if (!isValid) return;

                Object.assign(TrialSignup.formData, stepData);
                TrialSignup.nextStep(container);
            });
        }

        const options = container.querySelectorAll('.trial-option-card');
        options.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const value = e.currentTarget.dataset.value;
                const step = TrialSignup.steps[TrialSignup.currentStep];
                TrialSignup.formData[step.id] = value;
                TrialSignup.nextStep(container);
            });
        });

        const backBtn = container.querySelector('.trial-back');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                TrialSignup.currentStep = Math.max(0, TrialSignup.currentStep - 1);
                TrialSignup.render(container);
            });
        }
    },

    nextStep: (container) => {
        ConsumerUtils.saveProgress('trial_signup', {
            formData: TrialSignup.formData,
            currentStep: TrialSignup.currentStep
        });

        ConsumerUtils.logEvent('trial_step_completed', {
            step: TrialSignup.currentStep + 1,
            data: TrialSignup.formData
        });

        TrialSignup.currentStep++;
        TrialSignup.render(container);
    },

    showSuccess: (container) => {
        ConsumerUtils.logEvent('trial_signup_completed', {
            formData: TrialSignup.formData
        });

        container.innerHTML = `
            <div class="trial-success">
                <div class="success-icon">✓</div>
                <h2>Welcome to Sentient!</h2>
                <p>Your trial account is being set up for <strong>${TrialSignup.formData.email}</strong></p>
                
                <div class="success-details">
                    <h3>What's Next?</h3>
                    <div class="next-steps">
                        <div class="next-step">
                            <span class="step-number">1</span>
                            <div>
                                <strong>Check Your Email</strong>
                                <p>We've sent activation instructions to your inbox</p>
                            </div>
                        </div>
                        <div class="next-step">
                            <span class="step-number">2</span>
                            <div>
                                <strong>Activate Your Account</strong>
                                <p>Click the link in the email to get started</p>
                            </div>
                        </div>
                        <div class="next-step">
                            <span class="step-number">3</span>
                            <div>
                                <strong>Explore AI Capabilities</strong>
                                <p>Start with our guided tutorial and sample projects</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="trial-features">
                    <h4>Included in Your Trial</h4>
                    <ul>
                        <li>✓ Full access to all AI agents</li>
                        <li>✓ 1,000 automation credits</li>
                        <li>✓ Priority customer support</li>
                        <li>✓ 30-day money-back guarantee</li>
                    </ul>
                </div>

                <div class="success-actions">
                    <button class="btn-primary" onclick="window.location.href='/pages/alternate/contact_alt.html'">Schedule Onboarding Call</button>
                    <button class="btn-secondary share-trial">Share With Colleagues</button>
                </div>
            </div>
        `;

        const shareBtn = container.querySelector('.share-trial');
        if (shareBtn) {
            shareBtn.addEventListener('click', () => {
                const shareText = `I just started a free trial with Sentient AI! Join me in exploring advanced AI automation:`;
                if (navigator.share) {
                    navigator.share({
                        title: 'Join Sentient AI Trial',
                        text: shareText,
                        url: window.location.href
                    }).catch(err => {});
                }
                ConsumerUtils.logEvent('trial_shared', {});
            });
        }
    }
};

// =============================================================================
// INITIALIZATION
// =============================================================================

document.addEventListener('DOMContentLoaded', () => {
    AIDemo.init();
    AssessmentQuiz.init();
    SavingsCalculator.init();
    TrialSignup.init();
    
    // Consumer tools initialized
});

window.SentientConsumerTools = {
    AIDemo,
    AssessmentQuiz,
    SavingsCalculator,
    TrialSignup,
    ConsumerUtils
};